chrome.runtime.setUninstallURL("https://docs.google.com/forms/d/e/1FAIpQLSdxh8mQC5VN5Xv9vGaiZYviqzzLE43brXWsTkivEvwHCaoc4g/viewform?usp=sf_link");
